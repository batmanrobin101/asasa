
# MavicSolutions (Slim Repo)
This is a lightweight GitHub-ready repository.

Included:
- DUML summary
- Calibration tool (Python)
- Unit tests
- GitHub Actions workflow for CI tests

EXCLUDED:
- Large EXE files
- Binaries over 5MB
- Temporary build folders

This repo is safe to upload privately to GitHub.
